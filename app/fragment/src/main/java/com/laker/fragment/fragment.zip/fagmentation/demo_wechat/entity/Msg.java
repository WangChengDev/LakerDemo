package com.laker.fragment.fagmentation.demo_wechat.entity;

/**
 * Created by YoKeyword on 16/6/30.
 */
public class Msg {
    public String message;

    public Msg(){}

    public Msg(String msg){
        message = msg;
    }
}
