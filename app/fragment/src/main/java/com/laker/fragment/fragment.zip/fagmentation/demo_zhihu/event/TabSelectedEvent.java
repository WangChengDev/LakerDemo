package com.laker.fragment.fagmentation.demo_zhihu.event;

/**
 * Created by YoKeyword on 16/6/5.
 */
public class TabSelectedEvent {
    public int position;

    public TabSelectedEvent(int position) {
        this.position = position;
    }
}
